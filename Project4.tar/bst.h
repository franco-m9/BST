#ifndef BST_H
#define BST_H

#include <iostream>
#include <string>
using namespace std;
namespace cop4530 {

const int default_threshold_value=1;

template <typename T>
class BST
{
public:
	BST(int th=default_threshold_value);
	BST(const string input, int th=default_threshold_value);
	BST(const BST&rhs);
	BST(BST&&rhs);
	~BST();
	void buildFromInputString(const string input);
	const BST & operator=(const BST & rhs);
	const BST & operator=(BST&&rhs);
	bool empty() const;
	void printInOrder() const;
	void printLevelOrder() const;
	int numOfNodes() const;
	int height() const;
	void makeEmpty();
	void insert(const T& v);
	void insert(T &&v);
	void remove(const T& v);
	bool contains(const T& v);
private:
	struct BSTNode {
	    T element;
	    int rcounter;
	    BSTNode *left;
	    BSTNode *right;

	    BSTNode(const T &theElement, BSTNode *lt, BSTNode *rt, int cnt =0)
		: element{theElement}, left{lt}, right{rt}, rcounter{0} {}
	    BSTNode(T && theElement, BSTNode *lt, BSTNode *rt)
		: element{std::move(theElement)}, left{lt}, right{rt} {}
	};

	BSTNode *root;
	int threshold;
	void printInOrder(BSTNode *t) const;
	void printLevelOrder(BSTNode *t) const;
	void makeEmpty(BSTNode *&t);
	void insert(const T& v, BSTNode *&t);
	void insert(T &&v, BSTNode *&t);
	void remove(const T& v, BSTNode *&t);
	bool contains(const T& v, BSTNode *&t, BSTNode *&tt); 
	int numOfNodes(BSTNode *t) const;	
	int height(BSTNode *t) const;
	BSTNode * clone(BSTNode *t) const;
	BSTNode * findMin(BSTNode*t) const;
	void rotation(BSTNode * &t, BSTNode * &tt);
};

}
#include "bst.hpp"

#endif
