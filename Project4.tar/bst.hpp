#include "bst.h"
#include <iostream>
#include <sstream>
#include <queue>

using namespace std;
using namespace cop4530;

template <typename T>
BST<T>::BST(int th) : root{nullptr}, threshold{th}
{

}

template <typename T>
BST<T>::BST(const string input, int th) : root{nullptr}, threshold{th}
{
buildFromInputString(input);
}

template <typename T>
BST<T>::BST(const BST&rhs) : root{nullptr}
{
root = clone(rhs.root);
}

template <typename T>
BST<T>::BST(BST&&rhs) : root{nullptr}
{
swap(rhs.root,root);
}

template <typename T>
BST<T>::~BST()
{
makeEmpty();
}

template <typename T>
void BST<T>:: buildFromInputString(const string input)
{
if(empty()==false)
makeEmpty();

stringstream inp(input);
T v;

while(inp>>v)
insert(v);
}

template <typename T>
const BST<T>& BST<T>::operator=(const BST & rhs)
{
root = clone(rhs.root);
}

template <typename T>
const BST<T>& BST<T>::operator=(BST&&rhs)
{
swap(root,rhs.root);
return *this;
}

template <typename T>
bool BST<T>::empty() const
{
return(root==nullptr);
}

template <typename T>
void BST<T>::printInOrder() const
{
if(empty()==true)
	cout << endl;
else
	printInOrder(root);			
	
cout << endl;
}

template <typename T>
void BST<T>::printLevelOrder() const
{
if(empty()==true)
	cout << endl;
printLevelOrder(root);
}

template <typename T>
int BST<T>::numOfNodes() const
{
numOfNodes(root);
}

template <typename T>
int BST<T>::height() const
{
return height(root);
}

template <typename T>
void BST<T>::makeEmpty()
{
makeEmpty(root);
}

template <typename T>
void BST<T>::insert(const T& v)
{
insert(v,root);
}

template <typename T>
void BST<T>::insert(T &&v)
{
insert(std::move(v),root);
}

template <typename T>
void BST<T>::remove(const T& v)
{
remove(v, root);
}

template <typename T>
bool BST<T>::contains(const T& v)
{
if(root->element==v)
{
root->rcounter=0;
return true;
}

return contains(v, root, root);
}

template <typename T>
void BST<T>::printInOrder(BSTNode *t) const
{
	if(t!=nullptr)
	{
	printInOrder(t->left);
	cout << t->element << " ";
	printInOrder(t->right);
	}
}

template <typename T>
void BST<T>::printLevelOrder(BSTNode *t) const
{
if(t==nullptr)
return;

queue<BSTNode*> transversal;
transversal.push(t);

if(transversal.empty()==false)
{
do
{
BSTNode * front = transversal.front();
cout << front->element << " ";

if(front->left!=nullptr)
	transversal.push(front->left);

if(front->right!=nullptr)
	transversal.push(front->right);

transversal.pop();
}while(transversal.empty()==false);
}
cout << endl;
}

template <typename T>
void BST<T>::makeEmpty(BSTNode *&t)
{
	if(t!=nullptr)
	{
	makeEmpty(t->left);
	makeEmpty(t->right);
	delete t;
	}
t=nullptr;
}

template <typename T>
void BST<T>::insert(const T& v, BSTNode *&t)
{
        if( t == nullptr )
            t = new BSTNode{ v, nullptr, nullptr };
        else if( v < t->element )
            insert( v, t->left );
        else if( t->element < v )
            insert( v, t->right );
        else
            ;  // Duplicate; do nothing
}

template <typename T>
void BST<T>::insert(T &&v, BSTNode *&t)
{
	if(t==nullptr)
		t = new BSTNode{std::move(v), nullptr, nullptr};
	else if(v<t->element)
		insert(std::move(v),t->left);
	else if(t->element<v)
		insert(std::move(v),t->right);
	else
		; // duplicate; do nothing
}

template <typename T>
void BST<T>::remove(const T& v, BSTNode *&t)
{
if(t==nullptr)
return;

	if(v<t->element)
	remove(v,t->left);
	else if(t->element<v)
	remove(v,t->right);
	else if(t->left!=nullptr && t->right!=nullptr)
	{
	t->element = findMin(t->right)->element;
	remove(t->element,t->right);
	}
	else
	{
	BSTNode * oldNode = t;
	t = (t->left!=nullptr) ? t->left : t->right;
	delete oldNode;
	}
}

template <typename T>
bool BST<T>::contains(const T& v, BSTNode *&t, BSTNode *& tt)
{
if(t==nullptr)
	return false;
else if(v<t->element)
	return contains(v,t->left,t);
else if(t->element<v)
	return contains(v,t->right,t);
else
{
	(t->rcounter)++;
		if(threshold <= t->rcounter)
		{
			t->rcounter = 0;
			rotation(t,tt);
		}
return true;	
}
}

template <typename T>
int BST<T>::numOfNodes(BSTNode *t) const
{
	if(t!=nullptr)
		return 1 + numOfNodes(t->left) + numOfNodes(t->right);
	else
		return 0;
}	

template <typename T>
int BST<T>:: height(BSTNode *t) const
{
int lheight, rheight;
	
	if(t==nullptr)
		return -1;
	else
	{
	lheight = height(t->left); 
	rheight = height(t->right);
	
		if(rheight>lheight)
			return rheight+1;
		else
			return lheight+1;
	}
}

template <typename T>
typename BST<T>::BSTNode* BST<T>::clone(BST<T>::BSTNode *t) const									
{
if(t==nullptr)
	return nullptr;
else
	return new BSTNode{t->element,clone(t->left),clone(t->right),t->rcounter};
}

template <typename T>
typename BST<T>::BSTNode * BST<T>::findMin(BSTNode*t) const				
{
if(t==nullptr)
	return nullptr;
if(t->left==nullptr)
	return t;

return findMin(t->left);
}

template <typename T>
void BST<T>::rotation(BSTNode * &t, BSTNode * &tt)
{
BSTNode * using1;
	if(t==tt->right)
	{
		using1 = tt;
		tt = t;
		using1->right = t->left;
		tt->left = using1;
	}
	else if(t==tt->left)
	{
		using1 = tt;
		tt = t;
		using1->left = t->right;
		tt->right = using1;
	}
	else
		return;
}
